import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import Dinner from "./components/mainPage";
import { tag } from "postcss-selector-parser";
import Counters from "./components/counters";

import { Route, BrowserRouter as Router, Link } from "react-router-dom";
import { Redirect } from "react-router";
import Table from "./components/table";
class mainMenu extends Component {
  state = {
    lunch: ["blah", "Rice", "sooru"],
    // imageUrl: 'import "./images/resto-logoo.png"',
    isDinnerClickd: true,
    lunchval: ""
  };
  render() {
    return (
      <Router>
        {this.state.isDinnerClickd === true ? (
          <div>
            <img src="./resto-logoo.png"></img>

            <ul>
              <li>
                <button onClick={this.handleClickLunch}>Lunch</button>
                <input
                  style={{ height: 20 }}
                  value={this.state.text}
                  onKeyPress={this.billTotal}
                />
              </li>
              <li>
                <button onClick={() => this.handleClickDinner()}>Dinner</button>
              </li>
            </ul>
          </div>
        ) : (
          <div>
            <Redirect to="/counters"></Redirect>
            <Route path="/counters" component={Counters} />
          </div>
        )}
      </Router>
    );
  }

  handleClickDinner = () => {
    console.log("inside dinner");
    this.setState({ isDinnerClickd: false });
  };

  handleClickLunch = ev => {
    console.log("Clicked", this);
    return (
      <div>
        <ul>
          {this.state.Lunch.map(tag => (
            <li>{key => tag}</li>
          ))}
        </ul>
      </div>
    );
  };
}

export default mainMenu;
