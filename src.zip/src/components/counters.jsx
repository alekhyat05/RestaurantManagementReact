import React, { Component } from "react";
import Dinner from "./mainPage";
import { Route, BrowserRouter as Router, Link } from "react-router-dom";
import { Redirect } from "react-router";
class Counters extends Component {
  state = {
    tableid: [{ id: 1 }, { id: 2 }]
  };
  render() {
    return (
      <Router>
        <ol>
          {this.state.tableid.map((tag, index) => (
            <li key={index}>
              <div>
                <Link to={`/mainPage/${tag.id}`}>Table Number</Link>
              </div>
            </li>
          ))}
        </ol>
        <Route name="mainPage" path="/mainPage/:id" component={Dinner} />
      </Router>
    );
  }

  /*
  handleTable = indexval => {
    console.log("indexval", indexval);
    {
      <Router>
        <Route
          path="/mainPage"
          render={props => <Dinner {...indexval} isAuthed={true} />}
        />
      </Router>;
    }
  };
*/
}

export default Counters;
