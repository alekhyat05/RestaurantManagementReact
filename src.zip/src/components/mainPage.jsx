import React, { Component } from "react";
import { tag } from "postcss-selector-parser";
import Autocomplete from "react-autocomplete";
import { arrayExpression } from "@babel/types";

class Dinner extends Component {
  state = {
    table: this.props.match.params,

    dinner: [
      { name: "egg", price: 20, count: 0, table: this.props.match.params },
      { name: "Rice", price: 50, count: 0, table: this.props.match.params },
      { name: "sooru", price: 100, count: 0, table: this.props.match.params },
      { name: "Sambar", price: 10, count: 0, table: this.props.match.params },
      { name: "Samosa", price: 30, count: 0, table: this.props.match.params }
    ],
    testvalue: this.props.value,
    id: this.props.match.params,
    autoCompleteArray: [],
    text: 0,
    value: ""
  };

  render() {
    console.log("tuturuu", this.state.id);
    return (
      <div>
        <h1>Dinner Cart</h1>
        <Autocomplete
          getItemValue={item => item.name}
          items={this.state.dinner}
          shouldItemRender={(item, value) =>
            item.name.toLowerCase().indexOf(value.toLowerCase()) > -1
          }
          renderItem={(item, isHighlighted) => (
            <div
              key={item.name}
              style={{ background: isHighlighted ? "blue" : "white" }}
            >
              {item.name}
            </div>
          )}
          value={this.state.value}
          onChange={e => this.setState({ value: e.target.value })}
          onSelect={value => this.handleAutoComplete(value)}
        ></Autocomplete>

        <ol>
          {this.state.autoCompleteArray.map((tag, index) => (
            <li key={index}>
              <p>
                {tag.result.name}
                price
                {tag.result.price}
              </p>

              <button onClick={() => this.handleIncrement(index)}>+</button>
              <span className="badge badge-primary m-2">
                {tag.result.count}
              </span>
              <button onClick={() => this.handledecrement(index)}>-</button>
            </li>
          ))}
        </ol>
        <label>
          <h3>Total:</h3>
        </label>

        <input
          style={{ height: 20 }}
          value={this.state.text}
          onKeyPress={this.billTotal}
        />
      </div>
    );
  }
  handleAutoComplete = ev => {
    console.log("handleAutoComplete", ev);
    this.setState({ value: ev });

    let dinnerClone = [...this.state.dinner];
    let dummyarray = [...this.state.autoCompleteArray];
    let result = dinnerClone.find(obj => {
      return obj.name === ev;
    });
    console.log("EV VAL", result);
    console.log("testing value is :", this.state.table);

    dummyarray.push({ result });
    this.setState({ autoCompleteArray: dummyarray });

    //this.setState({ dinner: newClone });
    this.billTotal();
    this.setState({ value: "" });
  };

  handleIncrement = mir => {
    let dinnerData = [...this.state.autoCompleteArray];
    dinnerData[mir].result.count = dinnerData[mir].result.count + 1;

    this.setState({ autoCompleteArray: dinnerData });
    console.log("testvalue", this.state.testvalue);
    this.billTotal();
  };

  handledecrement = ev => {
    let dinnerClone = [...this.state.dinner];
    if (dinnerClone[ev].count != 0) {
      dinnerClone[ev].count = dinnerClone[ev].count - 1;
      this.setState({ dinner: dinnerClone });
      this.billTotal();
    }
  };

  billTotal = ev => {
    var sumTotal = 0;

    for (let i = 0; i < this.state.autoCompleteArray.length; i++) {
      var total =
        this.state.autoCompleteArray[i].result.count *
        this.state.autoCompleteArray[i].result.price;

      sumTotal = sumTotal + total;
    }
    this.setState({ text: sumTotal });
  };
}

export default Dinner;
